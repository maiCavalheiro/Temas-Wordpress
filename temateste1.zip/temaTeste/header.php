<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>

    // indica ao browser como o  mark-up deve de ser usado;
    <link rel="profile" href="http://gmpg.org/xfn/11" />
    //  indica o tipo de conteúdo e o conjunto de caracteres que está a ser usado;
    <meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
    // a tag wp_title vai gerar um título diferente para cada página. 
    <title><?php wp_title(''); ?></title>
    // insere automaticamente o stylesheet criado anteriormente (style.css). O wordpress detecta a sua localização e insere o url do ficheiro;
    <link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
    // gera o url de pingback, não é obrigatório mas convém usar;
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
    // ativa o suporte a comentários com vários níveis e também tem a tag wp_head que serve para inserir outras linhas de código nesta zona do tema (é uma tag muito usada pelos plugins).
    <?php if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' ); wp_head(); ?>

</head>
<body>
<div id="corpo">
    <div id="header">
        <?php bloginfo('name'); ?> // titulo do site
        <?php bloginfo('description'); ?> // descrição do site
         
        <ul id="nav">
            <li><a href="#">Página 1</a></li>
            <li><a href="#">Página 2</a></li>
            <li><a href="#">Página 3</a></li>
            <li><a href="#">Página 4</a></li>
        </ul>
    </div>