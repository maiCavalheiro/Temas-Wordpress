    <div id="footer">
        <p>&copy; 2012 - Todos os Direitos Reservados</p>
    </div>
     
</div>
     
</body>
</html>